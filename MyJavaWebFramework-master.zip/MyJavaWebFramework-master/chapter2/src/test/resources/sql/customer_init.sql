TRUNCATE customer;
INSERT INTO customer (name, contact, telephone, email, remark) VALUES ('customer1', 'Jack', '13112345678', 'jack@gmail.com', NULL);
INSERT INTO customer (name, contact, telephone, email, remark) VALUES ('customer2', 'Rose', '13612345678', 'rose@gmail.com', NULL);
