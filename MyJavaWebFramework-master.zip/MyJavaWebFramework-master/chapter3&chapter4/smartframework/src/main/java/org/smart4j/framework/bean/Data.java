package org.smart4j.framework.bean;

public class Data {
    private Object model;   //模型数据

    public Data(Object model) {
        this.model = model;
    }

    public Object getModel() {
        return model;
    }
}
